# GitHub'a Dosyaları Push Etme Rehberi

## 🚀 Hızlı Başla (5 Dakika)

### Adım 1: Dosyaları Bilgisayarına İndir

Şu dosyaları indir:
```
✅ index.html          (Ana dosya - YENİ VERSİYON)
✅ avatar-assets.js    (Avatar sistemi)
✅ firebase-manager.js (Firebase entegrasyonu)
✅ excel-parser.js     (Excel parser)
```

### Adım 2: GitHub Repository'e Ekle

Repository klasörüne (`assisttquiztime`) kopyala:
```
assisttquiztime/
├── index.html
├── avatar-assets.js
├── firebase-manager.js
├── excel-parser.js
├── README.md (opsiyonel)
└── .gitignore (opsiyonel)
```

### Adım 3: Git Komutlarını Çalıştır

**Terminal/PowerShell'de:**

```bash
# Repository klasörüne git
cd assisttquiztime

# Tüm değişiklikleri stage'e ekle
git add .

# Commit et
git commit -m "feat: Excel upload ve Firebase integration

- Excel dosyasından soru yükleme sistemi eklendi
- Soru tipleri: 1=Çoktan Seçmeli, 2=D/Y, 3=Çok Cevaplı
- Firebase Realtime Database entegrasyonu
- XLSX CDN linkini iyileştirildi
- QR kod URL optimize edildi"

# GitHub'a gönder
git push origin main
```

### Adım 4: GitHub Pages'i Kontrol Et

1. Sayfana git: `https://ataguclu1.github.io/assisttquiztime/`
2. Sayfayı yenile (Ctrl+F5 veya Cmd+Shift+R)
3. Cache'i temizle gerekirse

**Bitti! 🎉**

---

## 🔄 Dosya Güncelleme (İleri Kullanıcılar)

Eğer önceden yüklüyse:

```bash
# 1. Değişiklikleri gör
git status

# 2. Spesifik dosyayı güncelle
git add index.html

# 3. Commit et
git commit -m "fix: XLSX CDN linkini güncelle"

# 4. Push et
git push origin main
```

---

## 📋 Commit Mesajı Yazma (Best Practices)

```
feat: Feature ekle
fix: Bug düzelt
docs: Dokümantasyon ekle
style: Kod formatı (mantık değişikliği yok)
refactor: Kodu yeniden düzenle
test: Test ekle
chore: Build, dependency, vs.
```

**Örnek iyi commit:**
```
feat: Excel upload sistemi

- Admin panelinde Excel yükleme butonu
- Soru türlerini otomatik tanı (1, 2, 3)
- Firebase sesyon senkronizasyonu
- Hata handling ve validasyon
```

---

## 🆘 Sorun Giderme

### "fatal: not a git repository"

```bash
# Repository'yi initialize et
git init

# Remote'u ekle
git remote add origin https://github.com/ataguclu1/assisttquiztime.git
```

### "Everything up-to-date"

```bash
# Değişikliklerin yüklü olduğundan emin ol
git status

# Hiçbir değişiklik yoksa, dosyaları manuel kontrol et
```

### "CRLF will be converted to LF"

```bash
# Git'i ayarla (Windows için)
git config --global core.autocrlf true
```

---

## ✅ Kontrol Listesi

- [ ] Tüm dosyalar indirildi
- [ ] Repository klasörüne kopyalandı
- [ ] `git add .` yapıldı
- [ ] `git commit` yapıldı
- [ ] `git push` yapıldı
- [ ] GitHub'da dosyalar görülüyor
- [ ] Pages yayınlanıyor (`https://ataguclu1.github.io/assisttquiztime/`)
- [ ] Tarayıcıda yükleniyor (Ctrl+F5)

---

**Başarılı push sonrası, sayfanız ~1-2 dakika içinde update olur!** ⚡
