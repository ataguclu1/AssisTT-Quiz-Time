// Firebase Manager - Realtime ve veri yönetimi
class FirebaseManager {
  constructor(config) {
    this.config = config;
    this.db = null;
    this.auth = null;
    this.initialized = false;
  }

  async init() {
    try {
      // Firebase SDK'yı dinamik olarak yükle
      if (typeof firebase === 'undefined') {
        await this.loadFirebaseSDK();
      }
      
      firebase.initializeApp(this.config);
      this.db = firebase.database();
      this.auth = firebase.auth();
      this.initialized = true;
      
      console.log('Firebase başlatıldı');
      return true;
    } catch (error) {
      console.error('Firebase init hatası:', error);
      return false;
    }
  }

  loadFirebaseSDK() {
    return new Promise((resolve, reject) => {
      const scripts = [
        'https://www.gstatic.com/firebasejs/10.7.0/firebase-app.js',
        'https://www.gstatic.com/firebasejs/10.7.0/firebase-database.js',
        'https://www.gstatic.com/firebasejs/10.7.0/firebase-auth.js'
      ];

      let loaded = 0;
      
      scripts.forEach(src => {
        const script = document.createElement('script');
        script.src = src;
        script.onload = () => {
          loaded++;
          if (loaded === scripts.length) resolve();
        };
        script.onerror = reject;
        document.head.appendChild(script);
      });
    });
  }

  // Yeni oyun oturumu oluştur
  async createGameSession(gamePin, hostData) {
    if (!this.initialized) return null;

    const sessionData = {
      pin: gamePin,
      hostId: hostData.id,
      hostName: hostData.name,
      createdAt: firebase.database.ServerValue.TIMESTAMP,
      status: 'waiting', // waiting, playing, ended
      players: {},
      currentQuestion: -1,
      questions: hostData.questions || [],
      results: {}
    };

    try {
      await this.db.ref(`sessions/${gamePin}`).set(sessionData);
      console.log(`Oyun oturumu ${gamePin} oluşturuldu`);
      return sessionData;
    } catch (error) {
      console.error('Oturum oluşturma hatası:', error);
      return null;
    }
  }

  // Oyun oturumunu getir
  async getGameSession(gamePin) {
    if (!this.initialized) return null;

    try {
      const snapshot = await this.db.ref(`sessions/${gamePin}`).once('value');
      return snapshot.val();
    } catch (error) {
      console.error('Oturum getirme hatası:', error);
      return null;
    }
  }

  // Oyun oturumunu dinle (gerçek zamanlı)
  onGameSessionUpdate(gamePin, callback) {
    if (!this.initialized) return null;

    return this.db.ref(`sessions/${gamePin}`).on('value', (snapshot) => {
      callback(snapshot.val());
    });
  }

  // Oturum dinlemeyi kaldır
  offGameSessionUpdate(gamePin, callback) {
    if (!this.initialized) return;
    this.db.ref(`sessions/${gamePin}`).off('value', callback);
  }

  // Oyuncuyu oturuma ekle
  async addPlayerToSession(gamePin, player) {
    if (!this.initialized) return false;

    try {
      const playerData = {
        id: player.id,
        name: player.name,
        avatar: player.avatar,
        joinedAt: firebase.database.ServerValue.TIMESTAMP,
        currentQuestion: -1,
        score: 0,
        answers: {}
      };

      await this.db.ref(`sessions/${gamePin}/players/${player.id}`).set(playerData);
      console.log(`Oyuncu ${player.name} eklendi`);
      return true;
    } catch (error) {
      console.error('Oyuncu ekleme hatası:', error);
      return false;
    }
  }

  // Oyuncuyu dinle
  onPlayerUpdates(gamePin, playerId, callback) {
    if (!this.initialized) return null;

    return this.db.ref(`sessions/${gamePin}/players/${playerId}`).on('value', (snapshot) => {
      callback(snapshot.val());
    });
  }

  // Oyuncu cevapını kaydet
  async savePlayerAnswer(gamePin, playerId, questionIndex, selectedOptions) {
    if (!this.initialized) return false;

    try {
      const path = `sessions/${gamePin}/players/${playerId}/answers/${questionIndex}`;
      await this.db.ref(path).set({
        selected: selectedOptions, // Array of indices
        timestamp: firebase.database.ServerValue.TIMESTAMP
      });
      return true;
    } catch (error) {
      console.error('Cevap kaydetme hatası:', error);
      return false;
    }
  }

  // Mevcut soruyu güncelle (Host tarafından)
  async updateCurrentQuestion(gamePin, questionIndex) {
    if (!this.initialized) return false;

    try {
      await this.db.ref(`sessions/${gamePin}/currentQuestion`).set(questionIndex);
      return true;
    } catch (error) {
      console.error('Soru güncelleme hatası:', error);
      return false;
    }
  }

  // Oyun durumunu güncelle
  async updateGameStatus(gamePin, status) {
    if (!this.initialized) return false;

    try {
      await this.db.ref(`sessions/${gamePin}/status`).set(status);
      return true;
    } catch (error) {
      console.error('Durum güncelleme hatası:', error);
      return false;
    }
  }

  // Oturumu sil
  async deleteGameSession(gamePin) {
    if (!this.initialized) return false;

    try {
      await this.db.ref(`sessions/${gamePin}`).remove();
      console.log(`Oyun oturumu ${gamePin} silindi`);
      return true;
    } catch (error) {
      console.error('Oturum silme hatası:', error);
      return false;
    }
  }

  // Soruları kaydet (Admin tarafından)
  async saveQuestions(quizId, questions) {
    if (!this.initialized) return false;

    try {
      await this.db.ref(`quizzes/${quizId}/questions`).set(questions);
      console.log(`${questions.length} soru kaydedildi`);
      return true;
    } catch (error) {
      console.error('Soru kaydetme hatası:', error);
      return false;
    }
  }

  // Soruları getir
  async getQuestions(quizId) {
    if (!this.initialized) return null;

    try {
      const snapshot = await this.db.ref(`quizzes/${quizId}/questions`).once('value');
      return snapshot.val();
    } catch (error) {
      console.error('Soru getirme hatası:', error);
      return null;
    }
  }

  // Leaderboard'u getir
  async getLeaderboard(gamePin) {
    if (!this.initialized) return [];

    try {
      const snapshot = await this.db.ref(`sessions/${gamePin}/players`).once('value');
      const players = snapshot.val() || {};
      
      // Oyuncuları score'a göre sırala
      return Object.values(players)
        .sort((a, b) => (b.score || 0) - (a.score || 0))
        .slice(0, 10); // Top 10
    } catch (error) {
      console.error('Leaderboard hatası:', error);
      return [];
    }
  }

  // Sonuçları hesapla ve kaydet
  async calculateAndSaveResults(gamePin, questions) {
    if (!this.initialized) return null;

    try {
      const sessionSnapshot = await this.db.ref(`sessions/${gamePin}`).once('value');
      const session = sessionSnapshot.val();
      
      const results = {};
      const players = session.players || {};

      // Her oyuncu için sonuçları hesapla
      for (const [playerId, player] of Object.entries(players)) {
        let correctCount = 0;
        let totalScore = 0;

        // Her soru için kontrol et
        for (const [qIndex, question] of questions.entries()) {
          const playerAnswer = player.answers?.[qIndex]?.selected || [];
          const correct = this.checkAnswer(playerAnswer, question.correctAnswers);
          
          if (correct) {
            correctCount++;
            totalScore += 100; // Doğru cevap = 100 puan
          }
        }

        results[playerId] = {
          playerId: playerId,
          playerName: player.name,
          correctAnswers: correctCount,
          totalQuestions: questions.length,
          score: totalScore,
          percentage: Math.round((correctCount / questions.length) * 100)
        };
      }

      // Sonuçları kaydet
      await this.db.ref(`sessions/${gamePin}/results`).set(results);
      
      return results;
    } catch (error) {
      console.error('Sonuç hesaplama hatası:', error);
      return null;
    }
  }

  // Cevap kontrolü
  checkAnswer(selectedIndexes, correctIndexes) {
    if (!selectedIndexes || !correctIndexes) return false;

    // Çoktan seçmeli (1 cevap)
    if (correctIndexes.length === 1 && selectedIndexes.length === 1) {
      return selectedIndexes[0] === correctIndexes[0];
    }

    // Çok cevaplı (birden fazla doğru cevap)
    if (correctIndexes.length > 1 && selectedIndexes.length > 0) {
      // Seçilen tüm cevaplar doğru mu, ekstra seçenek yok mu?
      const sorted1 = selectedIndexes.sort((a, b) => a - b);
      const sorted2 = correctIndexes.sort((a, b) => a - b);
      return JSON.stringify(sorted1) === JSON.stringify(sorted2);
    }

    return false;
  }
}
