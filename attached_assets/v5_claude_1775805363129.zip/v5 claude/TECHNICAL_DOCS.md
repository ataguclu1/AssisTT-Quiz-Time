# AssisTT Quiz Time - Teknik Dokümantasyon

## 🏗️ Mimarisi

```
┌─────────────────────────────────────────────┐
│           Admin Panel (PC)                  │
│  - Soru Yönetimi                           │
│  - Excel Upload                            │
│  - Oyun Yönetimi                          │
└──────────────┬──────────────────────────────┘
               │
        ┌──────▼────────┐
        │  Localhost    │ (veya GitHub Pages)
        │  index.html   │
        └──────┬────────┘
               │
    ┌──────────┴───────────┐
    │                      │
  QR Code             Join Pin
    │                      │
    ▼                      ▼
┌──────────────────────────────────┐
│    Telefon (Oyuncu)              │
│  - Safari/Chrome via QR          │
│  - Soru Cevaplama                │
│  - Real-time Score               │
└──────────────┬───────────────────┘
               │
         ┌─────▼──────┐
         │  Firebase  │
         │  Realtime  │
         │  Database  │
         └────────────┘
```

## 📁 Dosya Yapısı

```
/
├── index.html              # Ana oyun dosyası (52KB) - Tüm mantık burada
├── avatar-assets.js        # Avatar SVG generatörü (1.5KB)
├── firebase-manager.js     # Firebase CRUD işlemleri (8KB) - Future use
├── excel-parser.js         # Excel parse modülü (6KB) - Future use
└── SETUP_GUIDE_TR.md       # Kurulum rehberi
```

## 🔄 Veri Akışı

### 1. Excel Yükleme Akışı

```
User selects Excel
        │
        ▼
handleExcelUpload()
        │
        ├─ FileReader.readAsArrayBuffer()
        │
        ├─ XLSX.read() [CDN'den]
        │
        ├─ Parse headers ve rows
        │
        ├─ Her row için:
        │  ├─ Soru türünü belirle (1/2/3)
        │  ├─ Seçenekleri topla (A-E)
        │  ├─ Doğru cevapları bul
        │  └─ Question object oluştur
        │
        ├─ questions[] array'e ekle
        │
        ├─ saveQ() → localStorage
        │
        ├─ renderQL() → UI güncelle
        │
        └─ toast() → Başarı mesajı
```

### 2. Oyun Oturumu Başlatma

```
Host: "Lobiyi Başlat" tıkla
        │
        ▼
startLobby() → startLobbyFixed()
        │
        ├─ Validasyon: En az 1 soru var mı?
        │
        ├─ gamePin = random 6 digit
        │
        ├─ Firebase session oluştur:
        │  └─ /sessions/{gamePin}
        │
        ├─ localStorage.setItem() [offline compat]
        │
        ├─ QR Code generate et
        │  └─ URL: ?join={gamePin}
        │
        └─ pollLobby() başla [700ms interval]
                │
                ├─ Firebase'i dinle
                ├─ players {} güncelle
                └─ updatePlayerChips() → UI
```

### 3. Telefon Katılım Akışı

```
Phone: QR kodu oku veya kod gir
        │
        ▼
URL parse: ?join={gamePin}
        │
        ├─ show('join')
        │
        ├─ #join-pin.value = gamePin
        │
        └─ User: "Katıl" tıkla
                │
                ▼
          doJoinGame()
                │
                ├─ Player object oluştur
                │  ├─ id: random UUID
                │  ├─ name: User input
                │  ├─ avatar: DiceBear config
                │  └─ score: 0
                │
                ├─ Firebase'e ekle:
                │  └─ /sessions/{gamePin}/players/{id}
                │
                ├─ localStorage compat
                │
                └─ Waiting screen göster
                        │
                        └─ pollGame() başla
                           [Sorular bekleniyor]
```

### 4. Soru Yanıtlama Akışı

```
Host: "Soruyu Göster" (showHostQuestion)
        │
        ├─ Firebase: /sessions/{gamePin}/currentQuestion = qIdx
        │
        └─ localStorage update
                │
                ▼ (Tüm cihazlar dinliyor)
                │
     ┌──────────┴──────────┐
     │                     │
  Host Device        Player Phones
     │                     │
     ├─ Soru göster    ├─ Soru göster
     ├─ 20 sn timer   ├─ Answer UI
     └─ Cevapları        │
        sakla              ├─ User seçim yap
                          │
                          └─ onAnswerSelect()
                             │
                             ├─ Validate answer
                             │
                             ├─ Firebase save:
                             │  └─ /sessions/{gamePin}/
                             │      players/{pid}/
                             │      answers/{qIdx}
                             │
                             └─ localStorage update
```

## 🔑 Anahtar Fonksiyonlar

### Excel Parsing

```javascript
handleExcelUpload(event)
├─ FileReader ile dosya oku
├─ XLSX.read() ile parse et
├─ Başlıkları ve verileri mapla
├─ Question object'ler oluştur
└─ questions[] array'e ekle

// Question Object Yapısı (Excel'den):
{
  text: "Soru metni",
  type: "multiple" | "trueFalse" | "multiAnswer",
  answers: [
    { text: "Seçenek A", correct: false },
    { text: "Seçenek B", correct: true },
    ...
  ],
  time: 20,      // Saniye
  pts: "standard"  // Puan çarpanı
}
```

### Firebase Session Management

```javascript
syncGameSession()
├─ Session ref: /sessions/{gamePin}
├─ Host state'ini gönder
└─ Realtime listener kurası

firebaseDB.ref('sessions/123456')
├─ READ: Oyuncu listesini al
├─ UPDATE: currentQuestion değiştir
├─ WRITE: Cevapları kaydet
└─ LISTEN: Gerçek zamanlı güncellemeler
```

### Scoring Logic

```javascript
checkAnswer(selectedIndexes, correctIndexes)
├─ Single answer (Tip 1):
│  └─ selectedIndexes[0] === correctIndexes[0]
│
└─ Multi answer (Tip 3):
   └─ JSON.stringify(sorted selected) === 
      JSON.stringify(sorted correct)

calculateScore(question, timeLeft)
├─ Base: 100 puan
├─ Time bonus: +Math.floor(timeLeft * 5)
├─ Multiplier:
│  ├─ "standard" → 1x
│  ├─ "double" → 2x
│  └─ "none" → 0x
└─ Total: base * multiplier + bonus
```

## 🔐 Firebase Database Schema

```
assistt-quiz-time/
├── sessions/
│   └── {gamePin}/
│       ├── pin: "123456"
│       ├── host: true|false
│       ├── phase: "lobby"|"playing"|"leaderboard"|"ended"
│       ├── players/
│       │   └── {playerId}/
│       │       ├── id: "uuid..."
│       │       ├── name: "Oyuncu Adı"
│       │       ├── avatar: {...}
│       │       ├── score: 1500
│       │       ├── joinedAt: timestamp
│       │       └── answers/
│       │           └── {questionIndex}/
│       │               ├── selected: [0, 2]
│       │               └── timestamp: ...
│       ├── questions: [...] (host'ın soruları)
│       ├── currentQuestion: 3
│       └── timestamp: ...
│
└── quizzes/
    └── {quizId}/
        ├── name: "Sınav Adı"
        ├── questions: [...]
        └── createdAt: timestamp
```

## 🎯 URL Yapısı

```
Anasayfa (Landing):
  https://ataguclu1.github.io/assisttquiztime/

Host login:
  https://ataguclu1.github.io/assisttquiztime/
  → Admin panele gir

Oyuncu join (QR ile):
  https://ataguclu1.github.io/assisttquiztime/?join=123456

Oyuncu join (Elle):
  https://ataguclu1.github.io/assisttquiztime/
  → Kod gir → Katıl
```

## 🌐 Harici Bağımlılıklar (CDN)

```javascript
// Yüklü CDN'ler:
- QRCode.js (QR kod)
- Firebase SDK v10.7.0 (Database + Auth)
- XLSX.js v2.8.0 (Excel)
- Google Fonts (Montserrat)
- DiceBear API (Avatar)

// Yerel dosyalar:
- avatar-assets.js (DiceBear wrapper)
- firebase-manager.js (Optional future)
- excel-parser.js (Optional future)
```

## 📊 Veri Tipleri

```javascript
// Question
type Question = {
  text: string
  type: 'multiple' | 'trueFalse' | 'multiAnswer'
  answers: Answer[]
  time: number  // seconds
  pts: 'standard' | 'double' | 'none'
}

type Answer = {
  text: string
  correct: boolean
}

// Player
type Player = {
  id: string
  name: string
  avatar: {
    style: string
    seed: string
  }
  score: number
  joinedAt: number  // timestamp
  answers: {
    [questionIndex]: {
      selected: number[]
      timestamp: number
    }
  }
}

// Game Session
type GameSession = {
  pin: string
  host: boolean
  phase: 'lobby' | 'playing' | 'leaderboard' | 'ended'
  players: { [playerId]: Player }
  questions: Question[]
  currentQuestion: number
  timestamp: number
}
```

## ⚙️ Yapılandırma Sabirleri

```javascript
// Oyun Ayarları
const GAME_CONFIG = {
  DEFAULT_QUESTION_TIME: 20,  // saniye
  MIN_PLAYERS: 1,
  MAX_PLAYERS: 100,
  TIMER_INTERVAL: 1000,  // ms
  POLL_INTERVAL: 700,    // ms
  AUTO_NEXT_DELAY: 3000, // ms
  SCORE_BASE: 100,
  TIME_BONUS_RATE: 5,    // puan/saniye
}

// Firebase
const FIREBASE_PATHS = {
  SESSIONS: 'sessions',
  PLAYERS: 'players',
  QUESTIONS: 'questions',
  RESULTS: 'results',
}

// Admin
const ADMIN_CONFIG = {
  DEFAULT_PASSWORD: 'admin123',
  SESSION_KEY_PREFIX: 'ql_game_',
  QUESTIONS_KEY: 'ql_q',
  PASSWORD_KEY: 'ql_pw',
}
```

## 🚀 Deployment

### GitHub Pages
```bash
# 1. Push to main branch
git push origin main

# 2. GitHub Settings → Pages → Deploy from main
# 3. Otomatik https://ataguclu1.github.io/assisttquiztime/ yayınlanır
```

### Kendi Sunucusunda
```bash
# Nginx
location /assisttquiztime/ {
  root /var/www/html;
  index index.html;
  try_files $uri $uri/ /index.html;
}

# Apache
<Directory "/var/www/html/assisttquiztime">
  RewriteEngine On
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule ^ index.html [QSA,L]
</Directory>
```

## 🧪 Test Senaryoları

### Test 1: Excel Yükle
```
✓ Admin login
✓ Excel yükle
✓ Sorular listede görülüyor
✓ Sorular kayıtlı
```

### Test 2: QR Kod (PC → Phone)
```
✓ PC: "Lobiyi Başlat"
✓ QR kod gösteriliyor
✓ Phone: QR kodu oku
✓ Phone: Oyun kodu otomatik dolduruldu
✓ Phone: Katıl butonuna tıkla
✓ PC: Oyuncu görünüyor
```

### Test 3: Oyun Oyu
```
✓ PC: Oyunu başlat
✓ Phone: Soru görülüyor
✓ Phone: Cevap seç
✓ PC: Cevap kaydedildi
✓ PC: Sonraki soruya geç
✓ PC: Leaderboard göster
```

---

**Not:** Tüm modern tarayıcılar desteklenir (Chrome, Safari, Firefox, Edge)
