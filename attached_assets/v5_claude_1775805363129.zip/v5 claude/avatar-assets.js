// AssisTT Quiz Time Avatar Assets v2.0
// DiceBear API kullanılarak modern ve kurumsal avatar altyapısı oluşturulmuştur.

window.AVATAR_ASSETS = {
  // SVG Oluşturucu (Ana önizlemeler için)
  buildAvatarSVG(av) {
    const style = av.style || 'adventurer';
    const seed = av.seed || 'AssisTT';
    const url = `https://api.dicebear.com/7.x/${style}/svg?seed=${seed}&backgroundColor=b6e3f4,c0aede,d1d4f9,ffdfbf,ffd5dc&radius=50`;
    
    // SVG içine dışarıdan API görselini gömüyoruz
    return `<image href="${url}" width="100" height="100" />`;
  },

  // Mini SVG (Listeler, Liderlik tablosu ve Chipler için)
  buildMiniSVG(av, size = 40) {
    const style = av.style || 'adventurer';
    const seed = av.seed || 'AssisTT';
    const url = `https://api.dicebear.com/7.x/${style}/svg?seed=${seed}&backgroundColor=b6e3f4,c0aede,d1d4f9,ffdfbf,ffd5dc&radius=50`;
    
    return `<img src="${url}" width="${size}" height="${size}" style="border-radius:50%; object-fit: cover; border: 2px solid rgba(255,255,255,0.2);">`;
  }
};