# AssisTT Quiz Time - Kurulum & Kullanım Rehberi

## 🚀 Yapılan Güncellemeler

### 1. **Excel Soru Yükleme** ✅
- Admin panelinde `📊 Excel Yükle` butonu eklendi
- Excel dosyasını doğrudan sistemle yükleyebilirsiniz
- Formatı: Örnek dosya (`Mobil_Bireysel_OB_Yetiştirme_Eğitimi_Sınavı.xlsx`)

**Desteklenen Soru Türleri:**
- Tip 1: Çoktan Seçmeli (1 doğru cevap)
- Tip 2: Doğru/Yanlış
- Tip 3: Çok Cevaplı (2+ doğru cevap)

### 2. **QR Kod Sorunsuz Erişim** ✅
- Telefon Safari'de QR kodu okuttuğunda oyun kodunu almakta sorun yaşamaz
- URL yapısı optimize edildi
- Firebase Session Sync eklendi (gerçek zamanlı oyuncu güncellemeleri)

### 3. **Firebase Integration** ✅
- Realtime Database bağlantısı yapılmıştır
- Oyun oturumları Firebase'te saklanır
- Multiplayer senkronizasyon desteklenir

---

## 📦 Dosyalar ve Açıklamaları

### Ana Dosyalar
- **`index.html`** - Ana oyun dosyası (Tüm özellikler)
- **`firebase-manager.js`** - Firebase veri tabanı yönetimi (Henüz HTML'e entegre değil, geri compat için)
- **`excel-parser.js`** - Excel parse etme (Henüz HTML'e entegre değil, gelecek için)
- **`avatar-assets.js`** - Avatar sistemleri

---

## 🔧 Kurulum Adımları

### Yerel Makinede Çalıştırma (PC)

```bash
# 1. Dosyaları indir ve bir klasöre koy
# 2. Basit bir HTTP sunucusu başlat:

# Python 3 ile:
python -m http.server 8000

# Node.js (http-server) ile:
npx http-server

# 3. Tarayıcıda aç:
http://localhost:8000
```

### GitHub Pages'te Deploy Etme

```bash
# 1. Repository'de şu dosyaları içer:
- index.html
- avatar-assets.js
- firebase-manager.js
- excel-parser.js

# 2. GitHub Settings → Pages → Deploy from branch (main)
# 3. Site otomatik publish olur:
https://ataguclu1.github.io/assisttquiztime/
```

---

## 🎮 Kullanım Senaryosu

### **Senaryo 1: Excel'den Soru Yükleme**

1. **Admin Login**
   - Şifreyi gir (varsayılan: `admin123`)

2. **Excel Yükle**
   - `📊 Excel Yükle` butonuna tıkla
   - Dosya seç ve karşıya yükle
   - Sorular otomatik listeye eklenir

3. **Lobiyi Başlat**
   - `▶ Lobiyi Başlat` butonuna tıkla
   - Oyun kodu görünür (örn: `487291`)
   - QR kod oluşturulur

### **Senaryo 2: Telefondan Katılım**

**PC (Admin/Host):**
```
Oyun Kodu: 487291
QR Kod: [görselle gösterilir]
```

**Telefon (Oyuncu):**
1. QR kodu oku veya oyun kodunu gir
2. Adını seç ve avataını konfigüre et
3. "Katıl" butonuna tıkla
4. Host'ın oyunu başlatmasını bekle

**PC (Host):**
1. Oyuncular katıldıkça ekranda görülür
2. "🚀 OYUNU BAŞLAT" butonuna tıkla
3. Sorular başlar
4. Leaderboard otomatik güncellenir

---

## 📊 Excel Dosyası Formatı

Lütfen bu sütunları bu sırayla kullan:

| Sütun | Zorunlu? | Açıklama |
|-------|----------|----------|
| **Soru Tipi** | ✅ | 1, 2 veya 3 |
| **Soru Metni** | ✅ | Sorunun tam metni |
| Departman | ❌ | İgnore edilir |
| Eğitim | ❌ | İgnore edilir |
| Konu | ❌ | İgnore edilir |
| Amaç | ❌ | İgnore edilir |
| Bağlı Metin | ❌ | İgnore edilir |
| Derece | ❌ | İgnore edilir |
| Erişim Seviyesi | ❌ | İgnore edilir |
| **Seçenek Sayısı** | ✅ | 2-5 arasında |
| **A** | ✅ | 1. seçenek |
| **B** | ✅ | 2. seçenek |
| **C** | ✅ | 3. seçenek |
| **D** | ⚠️ | 4. seçenek (varsa) |
| **E** | ⚠️ | 5. seçenek (varsa) |
| **Doğru Seçenek 1** | ✅ | A, B, C, D, E şekilinde |
| **Doğru Seçenek 2** | ⚠️ | İkinci doğru cevap (Tip 3 için) |
| **Doğru Seçenek 3** | ⚠️ | Üçüncü doğru cevap (Tip 3 için) |
| **Doğru Seçenek 4** | ⚠️ | İlave |
| **Doğru Seçenek 5** | ⚠️ | İlave |
| Kodlama Sorusu | ❌ | İgnore edilir |

---

## 🔑 Firebase Yapılandırması

Firebase config zaten `index.html` içine gömüldü:

```javascript
const firebaseConfig = {
  apiKey: "AIzaSyA7ZWCeXXr9Ale5nadD1ZAoI46i18tFu6k",
  authDomain: "assistt-quiz-time.firebaseapp.com",
  databaseURL: "https://assistt-quiz-time-default-rtdb.firebaseio.com",
  projectId: "assistt-quiz-time",
  storageBucket: "assistt-quiz-time.firebasestorage.app",
  messagingSenderId: "343741235205",
  appId: "1:343741235205:web:d68c1d30180ee878739c6c"
};
```

Herhangi bir değişiklik gerekmez. Firebase otomatik çalışacaktır.

---

## 🐛 Sorun Giderme

### **"Oyun Kodu Bulunamadı" Hatası**
- ✅ **Çözüm:** QR kodu okuduktan sonra sayfa yüklüyse, URL'de `?join=XXXXXX` var mı kontrol et
- Eğer yoksa, oyun kodunu manuel olarak gir

### **QR Kod Safari'de Çalışmıyor**
- ✅ **Çözüm:** Dosyaları HTTPS'de sunduğundan emin ol (GitHub Pages otomatik HTTPS)
- Yerel sunucuda HTTP problem yaşanabilir - `http-server` kullan

### **Oyuncular Göze Gelmiyorlar**
- ✅ **Çözüm:** Browser console'da (F12) hataları kontrol et
- Firebase bağlantısı aktif mi? Network tabında kontrol et

### **Excel Dosyası Yüklenmiyor**
- ✅ **Çözüm:** Excel dosyasının .xlsx formatında olduğundan emin ol
- Başlık satırları tam olarak eşleşiyor mu kontrol et

---

## 📝 Notlar

- Sorular **localStorage**'de de saklanır (offline çalışabilir)
- Firebase'te sadece aktif oyun oturumları saklanır
- Admin şifresi varsayılan = `admin123` (Admin panelinden değiştirilebilir)

---

## 🤝 Destek

Sorular varsa veya sorun yaşarsan:
1. Browser Console'da hataları kontrol et (F12)
2. Network tab'da API çağrılarını izle
3. GitHub Issues açabilirsin

---

**Son Güncelleme:** April 2026  
**Sürüm:** 2.1 (Firebase + Excel Upload)
