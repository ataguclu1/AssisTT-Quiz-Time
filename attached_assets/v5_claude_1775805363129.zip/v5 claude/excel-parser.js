// Excel Parser - Excel dosyasını soru formatına dönüştür
class ExcelQuestionParser {
  static async parseFile(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target.result);
          const workbook = XLSX.read(data, { type: 'array' });
          const worksheet = workbook.Sheets[workbook.SheetNames[0]];
          const rows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
          
          const questions = [];
          const headers = rows[0]; // İlk satır başlıklar
          
          // Başlık indeksleri bul
          const indexes = {
            soruTipi: headers.indexOf('Soru Tipi'),
            soruMetni: headers.indexOf('Soru Metni'),
            seçenekSayısı: headers.indexOf('Seçenek Sayısı'),
            a: headers.indexOf('A'),
            b: headers.indexOf('B'),
            c: headers.indexOf('C'),
            d: headers.indexOf('D'),
            e: headers.indexOf('E'),
            doğru1: headers.indexOf('Doğru Seçenek 1'),
            doğru2: headers.indexOf('Doğru Seçenek 2'),
            doğru3: headers.indexOf('Doğru Seçenek 3'),
            doğru4: headers.indexOf('Doğru Seçenek 4'),
            doğru5: headers.indexOf('Doğru Seçenek 5'),
          };
          
          // 2. satırdan başla (1. satır başlıklar)
          for (let i = 1; i < rows.length; i++) {
            const row = rows[i];
            
            // Boş satırları atla
            if (!row[indexes.soruMetni]) continue;
            
            const soruTipi = row[indexes.soruTipi];
            const soruMetni = row[indexes.soruMetni];
            const seçenekSayısı = row[indexes.seçenekSayısı] || 4;
            
            // Seçenekleri topla
            const seçenekler = [];
            const seçenekLabels = ['a', 'b', 'c', 'd', 'e'];
            
            for (let j = 0; j < seçenekSayısı; j++) {
              const seçenek = row[indexes[seçenekLabels[j]]];
              if (seçenek) {
                seçenekler.push(seçenek);
              }
            }
            
            // Doğru cevapları bul (A, B, C, D, E formatında)
            const doğruCevaplar = [];
            const doğruIndexes = [indexes.doğru1, indexes.doğru2, indexes.doğru3, indexes.doğru4, indexes.doğru5];
            
            for (const idx of doğruIndexes) {
              if (idx !== -1 && row[idx]) {
                const cevap = row[idx].trim().toUpperCase();
                // Cevap A, B, C, D, E ise işaretle
                const cevapIndex = seçenekLabels.indexOf(cevap.toLowerCase());
                if (cevapIndex !== -1) {
                  doğruCevaplar.push(cevapIndex);
                }
              }
            }
            
            // Soru nesnesini oluştur
            const soru = {
              id: i - 1,
              type: soruTipi, // 1: Çoktan Seçmeli, 2: Doğru/Yanlış, 3: Çok Cevaplı
              text: soruMetni,
              options: seçenekler,
              correctAnswers: doğruCevaplar, // İndeks olarak saklı (0=A, 1=B, vb.)
              timestamp: new Date().toISOString()
            };
            
            questions.push(soru);
          }
          
          resolve(questions);
        } catch (error) {
          reject(new Error(`Excel parse hatası: ${error.message}`));
        }
      };
      
      reader.onerror = () => {
        reject(new Error('Dosya okuma hatası'));
      };
      
      reader.readAsArrayBuffer(file);
    });
  }

  // İndeks tabanlı cevapları harfe dönüştür (gösterim için)
  static indexesToLetters(indexes) {
    const letters = ['A', 'B', 'C', 'D', 'E'];
    return indexes.map(idx => letters[idx] || '?');
  }

  // Harfleri indekse dönüştür
  static lettersToIndexes(letters) {
    return letters.map(l => {
      const idx = ['A', 'B', 'C', 'D', 'E'].indexOf(l.toUpperCase());
      return idx !== -1 ? idx : 0;
    });
  }
}
